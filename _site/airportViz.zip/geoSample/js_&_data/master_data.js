var  sampleData = [{name: "San Francisco", coordinates: [-122.417,37.783], barheight: 100,airportName:"San Francisco International Airport", airportCode:"SFO"},
    {name: "Los Angeles", coordinates: [-118.682,33.52], barheight: 80,airportName:"Los Angeles International Airport", airportCode:"LAX"},
    {name: "Denver", coordinates: [-104.8778,39.673], barheight: 75,airportName:"Denver International Airport", airportCode:"DEN"},    
    {name: "St. Louis", coordinates: [-90.505,38.788], barheight: 65,airportName:"Lambert-St. Louis International Airport", airportCode:"STL"},
    {name: "Atlanta", coordinates: [-84.682,33.52], barheight: 90,airportName:"Atlanta International Airport", airportCode:"ATL"},
    {name: "Arizona", coordinates: [-112.682,33.52], barheight: 55,airportName:"Phoenix Sky Harbor International Airport", airportCode:"PHX"},
    {name: "Minnesota", coordinates: [-93.682,44.52], barheight: 44,airportName:"St. Paul International Airport", airportCode:"MSP"},
    {name: "Chicago", coordinates: [-87.9067,41.988], barheight: 95,airportName:"Chicago O'hare International Airport", airportCode:"ORD"},
    {name: "Detroit", coordinates: [-83.417,42.783], barheight: 45,airportName:"Detroit Metro Airport", airportCode:"DTW"},
     {name: "Pittsburg", coordinates: [-80.682,40.52], barheight: 50,airportName:"Pittsburgh International Airport", airportCode:"PIT"},
      {name: "Charlotte", coordinates: [-80.682,35.52], barheight: 48,airportName:"Douglas International Airport", airportCode:"CLT"},
       {name: "New Jersey", coordinates: [-74.1682,41.52], barheight: 60,airportName:"Newark Liberty International Airport", airportCode:"EWR"},
     {name: "New York", coordinates: [-73.682,40.0952], barheight: 85,airportName:"John F. Kennedy International Airport", airportCode:"JFK"},
    {name: "Boston", coordinates: [-71.505,42.488], barheight: 40,airportName:"Boston Logan International Airport", airportCode:"BOS"},
    {name: "Texas", coordinates: [-100.682,31.52], barheight: 40, airportName:"Bush Intercontinental Airport", airportCode:"IAH"},
    {name: "Florida", coordinates: [-81.682,28.52], barheight: 34,airportName:"Orlando International Airport", airportCode:"MCO"}            
    ];

    var data11 = [{
                        "sale": "40",
                        "year": "1988"
                    },{
                        "sale": "120",
                        "year": "1992"
                    }, {
                        "sale": "215",
                        "year": "1996"
                    }, {
                        "sale": "239",
                        "year": "2000"
                    }, {
                        "sale": "299",
                        "year": "2004"
                    }, {
                        "sale": "334",
                        "year": "2008"
                    }];

                    var data12 = [{
                        "sale": "202",
                        "year": "1988"
                    },{
                        "sale": "152",
                        "year": "1992"
                    }, {
                        "sale": "215",
                        "year": "1996"
                    }, {
                        "sale": "179",
                        "year": "2000"
                    }, {
                        "sale": "199",
                        "year": "2004"
                    }, {
                        "sale": "134",
                        "year": "2008"
                    }];



    var data21 = [{
                        "sale": "102",
                        "year": "1988"
                    },{
                        "sale": "152",
                        "year": "1992"
                    }, {
                        "sale": "215",
                        "year": "1996"
                    }, {
                        "sale": "239",
                        "year": "2000"
                    }, {
                        "sale": "299",
                        "year": "2004"
                    }, {
                        "sale": "334",
                        "year": "2008"
                    }];

                    var data22 = [{
                        "sale": "202",
                        "year": "1988"
                    },{
                        "sale": "152",
                        "year": "1992"
                    }, {
                        "sale": "215",
                        "year": "1996"
                    }, {
                        "sale": "179",
                        "year": "2000"
                    }, {
                        "sale": "199",
                        "year": "2004"
                    }, {
                        "sale": "134",
                        "year": "2008"
                    }];

    var data31 = [{
                        "sale": "102",
                        "year": "1988"
                    },{
                        "sale": "152",
                        "year": "1992"
                    }, {
                        "sale": "215",
                        "year": "1996"
                    }, {
                        "sale": "239",
                        "year": "2000"
                    }, {
                        "sale": "299",
                        "year": "2004"
                    }, {
                        "sale": "334",
                        "year": "2008"
                    }];

                    var data32 = [{
                        "sale": "202",
                        "year": "1988"
                    },{
                        "sale": "152",
                        "year": "1992"
                    }, {
                        "sale": "215",
                        "year": "1996"
                    }, {
                        "sale": "179",
                        "year": "2000"
                    }, {
                        "sale": "199",
                        "year": "2004"
                    }, {
                        "sale": "134",
                        "year": "2008"
                    }];
                    

        var data41 = [{
                        "sale": "102",
                        "year": "1988"
                    },{
                        "sale": "152",
                        "year": "1992"
                    }, {
                        "sale": "215",
                        "year": "1996"
                    }, {
                        "sale": "239",
                        "year": "2000"
                    }, {
                        "sale": "299",
                        "year": "2004"
                    }, {
                        "sale": "334",
                        "year": "2008"
                    }];

                    var data42 = [{
                        "sale": "202",
                        "year": "1988"
                    },{
                        "sale": "152",
                        "year": "1992"
                    }, {
                        "sale": "215",
                        "year": "1996"
                    }, {
                        "sale": "279",
                        "year": "2000"
                    }, {
                        "sale": "329",
                        "year": "2004"
                    }, {
                        "sale": "374",
                        "year": "2008"
                    }];

        var data51 = [{
                        "sale": "102",
                        "year": "1988"
                    },{
                        "sale": "152",
                        "year": "1992"
                    }, {
                        "sale": "215",
                        "year": "1996"
                    }, {
                        "sale": "239",
                        "year": "2000"
                    }, {
                        "sale": "299",
                        "year": "2004"
                    }, {
                        "sale": "400",
                        "year": "2008"
                    }];

                    var data52 = [{
                        "sale": "200",
                        "year": "1988"
                    },{
                        "sale": "152",
                        "year": "1992"
                    }, {
                        "sale": "275",
                        "year": "1996"
                    }, {
                        "sale": "279",
                        "year": "2000"
                    }, {
                        "sale": "199",
                        "year": "2004"
                    }, {
                        "sale": "334",
                        "year": "2008"
                    }];


                    var data61 = [{
                        "sale": "142",
                        "year": "1988"
                    },{
                        "sale": "172",
                        "year": "1992"
                    }, {
                        "sale": "205",
                        "year": "1996"
                    }, {
                        "sale": "239",
                        "year": "2000"
                    }, {
                        "sale": "299",
                        "year": "2004"
                    }, {
                        "sale": "394",
                        "year": "2008"
                    }];

                    var data62 = [{
                        "sale": "202",
                        "year": "1988"
                    },{
                        "sale": "152",
                        "year": "1992"
                    }, {
                        "sale": "215",
                        "year": "1996"
                    }, {
                        "sale": "179",
                        "year": "2000"
                    }, {
                        "sale": "199",
                        "year": "2004"
                    }, {
                        "sale": "134",
                        "year": "2008"
                    }];

                    var data71 = [{
                        "sale": "109",
                        "year": "1988"
                    },{
                        "sale": "182",
                        "year": "1992"
                    }, {
                        "sale": "115",
                        "year": "1996"
                    }, {
                        "sale": "299",
                        "year": "2000"
                    }, {
                        "sale": "399",
                        "year": "2004"
                    }, {
                        "sale": "334",
                        "year": "2008"
                    }];

                    var data72 = [{
                        "sale": "202",
                        "year": "1988"
                    },{
                        "sale": "172",
                        "year": "1992"
                    }, {
                        "sale": "215",
                        "year": "1996"
                    }, {
                        "sale": "159",
                        "year": "2000"
                    }, {
                        "sale": "309",
                        "year": "2004"
                    }, {
                        "sale": "334",
                        "year": "2008"
                    }];

                    var data81 = [{
                        "sale": "38",
                        "year": "1988"
                    },{
                        "sale": "56",
                        "year": "1992"
                    }, {
                        "sale": "115",
                        "year": "1996"
                    }, {
                        "sale": "299",
                        "year": "2000"
                    }, {
                        "sale": "399",
                        "year": "2004"
                    }, {
                        "sale": "334",
                        "year": "2008"
                    }];

                    var data82 = [{
                        "sale": "29",
                        "year": "1988"
                    },{
                        "sale": "45",
                        "year": "1992"
                    }, {
                        "sale": "215",
                        "year": "1996"
                    }, {
                        "sale": "159",
                        "year": "2000"
                    }, {
                        "sale": "309",
                        "year": "2004"
                    }, {
                        "sale": "334",
                        "year": "2008"
                    }];